package com.a2zcreatorz.test.base;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.a2zcreatorz.test.MainActivity;
import com.a2zcreatorz.test.R;
import com.a2zcreatorz.test.model.User;
import com.a2zcreatorz.test.utils.AppConstants;
import com.a2zcreatorz.test.utils.Helper;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;

import java.util.Objects;

import static com.a2zcreatorz.test.utils.AppConstants.EMAIL;
import static com.a2zcreatorz.test.utils.AppConstants.FIRST_NAME;
import static com.a2zcreatorz.test.utils.AppConstants.LAST_NAME;
import static com.a2zcreatorz.test.utils.AppConstants.LATITUDE;
import static com.a2zcreatorz.test.utils.AppConstants.LONGITUDE;

public abstract class BaseActivity extends AppCompatActivity {

    private ProgressDialog dialog;
    private SharedPreferences.Editor editor;
    private SharedPreferences prefs;
    private LocationListener locationListener;
    private LocationManager locationManager;

    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(AppConstants.MY_PREFERENCE, MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public boolean networkAvailable() {
        return Helper.isNetworkAvailable(this);
    }

    public String getStringResource(int resource) {
        return getResources().getString(resource);
    }

    public boolean isLocationEnabled() {
        LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
        return service.isProviderEnabled(LocationManager.GPS_PROVIDER) || service.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

//    @SuppressLint("MissingPermission")
//    public Location getLocation() {
//        LocationManager lm = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
//        List<String> providers = lm.getProviders(true);
//        Location bestLocation = null;
//        for (String provider : providers) {
//            Location l = lm.getLastKnownLocation(provider);
//            if (l == null) {
//                continue;
//            }
//            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
//                bestLocation = l;
//            }
//        }
//        return bestLocation;
//    }

    public boolean isPermissionsGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public void getLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION}, AppConstants.PERMISSION_LOCATION);
    }

    @SuppressLint("MissingPermission")
    public void getLocation(LocationListener listener) {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = listener;
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
    }

    public void removeLocationListener() {
        locationManager.removeUpdates(locationListener);
    }

    public void showProgress(String message) {
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage(message);
        dialog.show();
    }

    public void hideProgress() {
        if (dialog.isShowing())
            dialog.dismiss();
    }

    public void initMap(MainActivity mainActivity) {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(mainActivity);
        } else
            getStringResource(R.string.something_wrong);
    }

    public void saveUserData(User user) {
        editor.putString(FIRST_NAME, user.getFirstName());
        editor.putString(LAST_NAME, user.getLastName());
        editor.putString(EMAIL, user.getEmail());
        editor.putString(LATITUDE, String.valueOf(user.getLatitude()));
        editor.putString(LONGITUDE, String.valueOf(user.getLongitude()));
        editor.apply();
    }

    public void clearUserData() {
        editor.clear();
        editor.apply();
    }

    public String getLoggedInUserName() {
        String firstName = prefs.getString(FIRST_NAME, "");
        String lastName = prefs.getString(LAST_NAME, "");
        return String.format("%s %s", firstName, lastName);
    }

    public LatLng getLoggedInLocation() {
        try {
            double lat = Double.valueOf(Objects.requireNonNull(prefs.getString(LATITUDE, "0")));
            double lng = Double.valueOf(Objects.requireNonNull(prefs.getString(LONGITUDE, "0")));

            return new LatLng(lat, lng);
        } catch (Exception ex) {
            return null;
        }
    }
}
