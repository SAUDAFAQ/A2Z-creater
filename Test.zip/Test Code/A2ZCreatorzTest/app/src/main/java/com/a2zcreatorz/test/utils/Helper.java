package com.a2zcreatorz.test.utils;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

import com.a2zcreatorz.test.R;
import com.a2zcreatorz.test.model.User;

public class Helper {

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static void startFadeInAnimation(View view) {
        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator());
        fadeIn.setDuration(2000);
        view.startAnimation(fadeIn);
    }

    public static void locationRequiredDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);
        builder.setMessage(context.getResources().getString(R.string.enable_location));
        builder.setPositiveButton(context.getResources().getString(R.string.ok), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    public static Bitmap getMarkerBitmapFromView(View customMarkerView) {

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
        customMarkerView.buildDrawingCache();
        Bitmap returnedBitmap = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
        Drawable drawable = customMarkerView.getBackground();
        if (drawable != null)
            drawable.draw(canvas);
        customMarkerView.draw(canvas);
        return returnedBitmap;
    }

    public static void showUserDetails(Context context, User user) {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.layout_user_details);
        dialog.setTitle(context.getResources().getString(R.string.txt_user_detail));

        ((TextView) dialog.findViewById(R.id.tvUserName)).setText(String.format("%s %s", user.getFirstName(), user.getLastName()));
        ((TextView) dialog.findViewById(R.id.tvEmail)).setText(user.getEmail());
        ((TextView) dialog.findViewById(R.id.tvlat)).setText(String.valueOf(user.getLatitude()));
        ((TextView) dialog.findViewById(R.id.tvlong)).setText(String.valueOf(user.getLongitude()));
        dialog.findViewById(R.id.ivClose).setOnClickListener(v -> dialog.dismiss());
        dialog.show();

    }
}
