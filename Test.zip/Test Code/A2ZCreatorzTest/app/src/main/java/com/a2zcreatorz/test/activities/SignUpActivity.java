package com.a2zcreatorz.test.activities;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.a2zcreatorz.test.MainActivity;
import com.a2zcreatorz.test.R;
import com.a2zcreatorz.test.base.BaseActivity;
import com.a2zcreatorz.test.model.User;
import com.a2zcreatorz.test.utils.AppConstants;
import com.a2zcreatorz.test.utils.Helper;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import static com.a2zcreatorz.test.utils.AppConstants.USERS;
import static com.a2zcreatorz.test.utils.AppConstants.USER_ACTIVE;
import static com.a2zcreatorz.test.utils.AppConstants.USER_STATUS;

public class SignUpActivity extends BaseActivity {

    private EditText etFirstName, etLastName, etEmail, etPass;
    private Button btnRegister;
    private LatLng myLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            FirebaseDatabase.getInstance().getReference(USERS)
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .child(USER_STATUS).setValue(USER_ACTIVE);

            startActivity(new Intent(this, MainActivity.class));
            finish();
        }

        initViews();
        initListener();
    }

    private void initViews() {
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
    }

    private void initListener() {
        btnRegister.setOnClickListener(v -> {
            if (networkAvailable())
                if (isDataValid())

                    if (isPermissionsGranted())
                        getLocationAndRegister();
                    else
                        getLocationPermission();

                else
                    showToast(getStringResource(R.string.fill_required_fields));
            else
                showToast(getStringResource(R.string.internet_not_available));
        });
    }

    private void getLocationAndRegister() {
        if (isLocationEnabled()) {
            showProgress(getStringResource(R.string.please_wait));

            getLocation(new LocationListener() {

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onProviderEnabled(String provider) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onProviderDisabled(String provider) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onLocationChanged(Location location) {
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();
                    myLocation = new LatLng(latitude, longitude);
                    removeLocationListener();

                    registerUser();
                }
            });
        } else
            Helper.locationRequiredDialog(this);
    }

    private void registerUser() {
        if (myLocation != null) {

            FirebaseAuth.getInstance()
                    .createUserWithEmailAndPassword(etEmail.getText().toString(), etPass.getText().toString())
                    .addOnCompleteListener(task -> {

                        if (task.isSuccessful()) {

                            saveDataAndLogin();
                        } else if (task.getException() != null) {
                            hideProgress();
                            showToast(getStringResource(R.string.register_failed) + task.getException().getLocalizedMessage());
                        }

                    });
        } else
            showToast(getStringResource(R.string.location_error));
    }

    private void saveDataAndLogin() {
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            User user = new User(etFirstName.getText().toString(),
                    etLastName.getText().toString(), etEmail.getText().toString(),
                    etPass.getText().toString(), myLocation.latitude,
                    myLocation.longitude, USER_ACTIVE);

            FirebaseDatabase.getInstance()
                    .getReference(AppConstants.USERS)
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .setValue(user)
                    .addOnCompleteListener(task -> {

                        hideProgress();
                        if (task.isSuccessful()) {

                            saveUserData(user);
                            startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                            finish();
                        } else if (task.getException() != null) {
                            showToast(getStringResource(R.string.register_failed) + task.getException().getLocalizedMessage());
                        }

                    });
        } else
            showToast(getStringResource(R.string.something_wrong));
    }

    private boolean isDataValid() {
        return !etFirstName.getText().toString().trim().isEmpty() &&
                !etLastName.getText().toString().trim().isEmpty() &&
                !etEmail.getText().toString().trim().isEmpty() &&
                !etPass.getText().toString().trim().isEmpty();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AppConstants.PERMISSION_LOCATION) {

            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                getLocationAndRegister();
            } else
                showToast(getStringResource(R.string.permission_required));
        } else {
            showToast(getStringResource(R.string.permission_required));
        }
    }
}
