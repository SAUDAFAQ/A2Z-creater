package com.a2zcreatorz.test;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.a2zcreatorz.test.activities.SignUpActivity;
import com.a2zcreatorz.test.base.BaseActivity;
import com.a2zcreatorz.test.model.User;
import com.a2zcreatorz.test.utils.Helper;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static com.a2zcreatorz.test.utils.AppConstants.USERS;
import static com.a2zcreatorz.test.utils.AppConstants.USER_ACTIVE;
import static com.a2zcreatorz.test.utils.AppConstants.USER_INACTIVE;
import static com.a2zcreatorz.test.utils.AppConstants.USER_STATUS;

public class MainActivity extends BaseActivity implements
        NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback {

    private Toolbar toolbar;
    private GoogleMap mMap;
    private String myUid = "";
    private View markerView;
    private boolean isMarkerPressed = false;

    @SuppressLint("InflateParams")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (FirebaseAuth.getInstance().getCurrentUser() != null)
            myUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        markerView = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.layout_marker, null);

        initToolbar();
        initDrawerAndNavigation();
        initMap(this);
    }

    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void initDrawerAndNavigation() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(0).setChecked(true);

        TextView tvUserName = navigationView.getHeaderView(0).findViewById(R.id.tvUserName);
        tvUserName.setText(getLoggedInUserName());
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng myLocation = getLoggedInLocation();

        if (myLocation != null) {
            if (networkAvailable())
                getUserData();
            else
                showToast(getStringResource(R.string.internet_not_available));

            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(myLocation)
                    .zoom(19).build();
            mMap.moveCamera(CameraUpdateFactory
                    .newCameraPosition(cameraPosition));
        }

        mMap.setOnMarkerClickListener(marker -> {
            if (networkAvailable()) {
                isMarkerPressed = true;
                FirebaseDatabase.getInstance().getReference(USERS)
                        .child(marker.getSnippet()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        User user = dataSnapshot.getValue(User.class);

                        if (user != null && isMarkerPressed)
                            Helper.showUserDetails(MainActivity.this, user);
                        isMarkerPressed = false;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            } else
                showToast(getStringResource(R.string.internet_not_available));
            return true;
        });
    }

    private void getUserData() {
        showProgress(getStringResource(R.string.please_wait));
        FirebaseDatabase.getInstance().getReference(USERS)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChildren()) {
                            mMap.clear();

                            for (DataSnapshot data : dataSnapshot.getChildren()) {
                                User user = data.getValue(User.class);
                                String userKey = data.getKey();

                                if (user != null)
                                    setMarker(user, userKey);
                            }

                            hideProgress();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        showToast(getStringResource(R.string.something_wrong));
                    }
                });
    }

    private void setMarker(User user, String userKey) {
        ((TextView) markerView.findViewById(R.id.tvMarkerName))
                .setText(String.format("%s %s", user.getFirstName(), user.getLastName()));
        markerView.findViewById(R.id.userStatus).setBackground(
                user.getLoggedIn().equals(USER_ACTIVE) ? getResources().getDrawable(R.drawable.status_online) :
                        getResources().getDrawable(R.drawable.status_offline));

        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(user.getLatitude(), user.getLongitude()))
                .snippet(userKey)
                .icon(BitmapDescriptorFactory
                        .fromBitmap(Helper.getMarkerBitmapFromView(markerView))));
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.action_home) {
            getUserData();
        }
        if (id == R.id.action_logout) {
            onLogout();
            startActivity(new Intent(this, SignUpActivity.class));
            finish();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void onLogout() {
        clearUserData();

        if (FirebaseAuth.getInstance().getCurrentUser() != null)
            FirebaseDatabase.getInstance().getReference(USERS)
                    .child(myUid)
                    .child(USER_STATUS).setValue(USER_INACTIVE);

        FirebaseAuth.getInstance().signOut();
    }

    @Override
    protected void onDestroy() {

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            FirebaseDatabase.getInstance().getReference(USERS)
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .child(USER_STATUS).setValue(USER_INACTIVE);
        }
        super.onDestroy();
    }
}
