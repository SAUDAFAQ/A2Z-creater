package com.a2zcreatorz.test.utils;

public class AppConstants {
    public static final String USERS = "Users";
    public static final String USER_STATUS = "loggedIn";

    public static final int PERMISSION_LOCATION = 11;
    public static final String MY_PREFERENCE = "A2ZCreatorz";

    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String EMAIL = "email";
    public static final String LATITUDE = "lat";
    public static final String LONGITUDE = "long";
    public static final String USER_ACTIVE = "1";
    public static final String USER_INACTIVE = "0";
}
