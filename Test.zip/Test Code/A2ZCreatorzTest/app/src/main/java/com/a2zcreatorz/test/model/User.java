package com.a2zcreatorz.test.model;

public class User {
    private String firstName, lastName, email, password, loggedIn;
    private double latitude, longitude;

    public User(String firstName, String lastName, String email, String password,
                double latitude, double longitude, String loggedIn) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.latitude = latitude;
        this.longitude = longitude;
        this.loggedIn = loggedIn;
    }

    public User() {
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getPassword() {
        return password;
    }

    public String getLoggedIn() {
        return loggedIn;
    }
}
